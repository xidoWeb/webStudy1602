HTML5-Photoshop-Sprite-Sheet-Creator
====================================

Documentation located at http://wmalone.com/spritesheet

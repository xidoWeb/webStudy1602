IE9.js
======

A JavaScript library to make MSIE behave like a standards-compliant browser.

Original code by Dean Edwards from http://code.google.com/p/ie7-js/.